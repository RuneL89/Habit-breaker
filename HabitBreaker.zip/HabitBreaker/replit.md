# Habit Breaker App

## Overview

A gamified habit tracking application that helps users break bad habits through positive reinforcement, achievement celebrations, and streak tracking. Built as a single-page application with a focus on playful, encouraging user experience inspired by Duolingo, Streaks, and Forest apps.

The app allows users to create habits they want to break, track their progress with real-time timers, unlock achievement badges at various milestones, and features a unique "shame modal" system that increases in severity based on streak length to discourage resetting progress.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, built using Vite for development and production builds.

**Routing**: Client-side routing using Wouter (lightweight React router).

**State Management**: 
- TanStack Query (React Query) for server state management
- Local React state (useState) for UI state
- LocalStorage for habit persistence (currently client-side only)

**UI Components**: 
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component library (New York style variant)
- Tailwind CSS for styling with custom design tokens
- Class Variance Authority (CVA) for component variants

**Design System**:
- Typography: Fredoka font family (rounded, friendly, approachable)
- Color scheme: Custom HSL-based color system with light/dark mode support
- Spacing: Tailwind units (2, 4, 6, 8) for consistent rhythm
- Gamification elements: Achievement badges, celebration modals, progress bars

**Key Features**:
- Real-time timer displays that update every second with countdown to next level
- Infinite level progression system (36 defined levels, exponential growth beyond)
  - Level 1-11 (Early): 30min, 1hr, 2hr, 4hr, 8hr, 12hr, 1d, 1.5d, 2d, 3d (instant start at L1)
  - Level 12-26 (Mid): 4-10 days, then 2-4 weeks, then 1.5-4 months
  - Level 27-36 (High): 5-12 months, then 1.5yr, 2yr, 3yr, 5yr, 10yr
- Visual grouping of achievements (Early Levels, Mid Levels, High Levels)
- Achievement display shows only unlocked levels + next 3 upcoming (greyed out)
- 30 rotating medal emojis with 16 tier titles (Novice → Unstoppable)
- Tiered shame modal system with 5 severity levels and 75 custom explicit messages
- Lost level display for Tier 3+ showing which levels will be permanently lost on reset
- Enhanced confirmation requirements: button clicks for low tiers, typing "I GIVE UP" for Tier 4, retyping goal for Tier 5
- Celebration modals with auto-dismiss and random encouragement messages
- Time formatting utilities showing clean durations (e.g., "3 days", "2 weeks")

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**API Design**: RESTful API with `/api` prefix (routes currently scaffolded but not implemented).

**Development Setup**:
- Vite middleware integration for HMR in development
- Custom logging middleware for API request tracking
- Raw body parsing for webhook support

**Storage Interface**: 
- Abstracted storage layer (IStorage interface)
- Currently using in-memory storage (MemStorage class)
- Designed to be swapped with database implementation

### Data Storage Solutions

**Current Implementation**: Client-side LocalStorage for habit persistence.

**Planned Database Schema** (Drizzle ORM with PostgreSQL):
- `habits` table with columns:
  - `id`: UUID primary key (auto-generated)
  - `name`: Text field for habit name
  - `emoji`: Text field for habit icon
  - `goal`: Text field describing why user wants to break the habit
  - `startedAt`: Integer timestamp (Unix epoch milliseconds)
  - `achievementsUnlocked`: Array of achievement IDs

**Database Configuration**:
- Drizzle Kit for migrations
- Neon Database serverless PostgreSQL driver
- Migration files output to `./migrations`

**Data Models**:
- Habit entity with insert/select schemas using Drizzle Zod
- Level progression system with 36 defined thresholds (exact durations from 30min to 10 years)
- Level groups for visual organization (Early 1-11, Mid 12-26, High 27+)
- 30 rotating medal emojis and 16 tier titles for level presentation
- Severity tiers for reset confirmations (5 levels: pathetic, weak, disappointing, tragic, devastating)
- Time formatting utilities (formatDuration, formatTimeAgo) for clean duration display

### External Dependencies

**Database**:
- Neon Database (serverless PostgreSQL) - configured but not yet connected
- Connection via `@neondatabase/serverless` driver

**UI Libraries**:
- Radix UI primitives (accordion, dialog, popover, progress, etc.)
- Embla Carousel for potential carousel components
- Lucide React for icons
- React Hook Form with Zod resolvers for form validation
- date-fns for date formatting

**Development Tools**:
- Vite plugins: React, runtime error overlay, Replit-specific plugins (cartographer, dev banner)
- TypeScript with strict mode enabled
- PostCSS with Tailwind and Autoprefixer

**Session Management**:
- connect-pg-simple for PostgreSQL-backed sessions (configured but not in use)

**Deployment Considerations**:
- Production build bundles client with Vite
- Server bundled with esbuild (ESM format, external packages)
- Environment variable `DATABASE_URL` required for database connection