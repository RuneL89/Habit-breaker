import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const habits = pgTable("habits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  emoji: text("emoji").notNull().default("🎯"),
  goal: text("goal").notNull(),
  startedAt: integer("started_at").notNull(),
  achievementsUnlocked: text("achievements_unlocked").array().notNull().default(sql`ARRAY[]::text[]`),
});

export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  achievementsUnlocked: true,
});

export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type Habit = typeof habits.$inferSelect;

// Legacy milestone system - kept for reference but replaced by levels
export const ACHIEVEMENT_MILESTONES = [
  { id: "1hour", label: "1 Hour", emoji: "⭐", duration: 60 * 60 * 1000 },
  { id: "6hours", label: "6 Hours", emoji: "🌟", duration: 6 * 60 * 60 * 1000 },
  { id: "1day", label: "1 Day", emoji: "🏆", duration: 24 * 60 * 60 * 1000 },
  { id: "3days", label: "3 Days", emoji: "💎", duration: 3 * 24 * 60 * 60 * 1000 },
  { id: "1week", label: "1 Week", emoji: "👑", duration: 7 * 24 * 60 * 60 * 1000 },
  { id: "2weeks", label: "2 Weeks", emoji: "🔥", duration: 14 * 24 * 60 * 60 * 1000 },
  { id: "1month", label: "1 Month", emoji: "🎖️", duration: 30 * 24 * 60 * 60 * 1000 },
] as const;

// ========================================
// INFINITE LEVEL PROGRESSION SYSTEM
// ========================================

// Medal emojis that rotate as you level up (30 unique medals)
const LEVEL_MEDALS = [
  "⭐", "🌟", "✨", "💫", "🏆", "🥇", "🥈", "🥉", 
  "💎", "💍", "👑", "🔥", "⚡", "🌈", "🎖️", "🏅",
  "🎯", "🎪", "🎨", "🎭", "🎬", "🎸", "🎺", "🎻",
  "🚀", "🛸", "💥", "🌠", "🔮", "🌌"
] as const;

// Tier titles based on level ranges
export interface LevelTier {
  minLevel: number;
  maxLevel: number;
  title: string;
}

export const LEVEL_TIERS: LevelTier[] = [
  { minLevel: 1, maxLevel: 5, title: "Novice" },
  { minLevel: 6, maxLevel: 10, title: "Apprentice" },
  { minLevel: 11, maxLevel: 15, title: "Warrior" },
  { minLevel: 16, maxLevel: 20, title: "Veteran" },
  { minLevel: 21, maxLevel: 25, title: "Champion" },
  { minLevel: 26, maxLevel: 30, title: "Master" },
  { minLevel: 31, maxLevel: 35, title: "Hero" },
  { minLevel: 36, maxLevel: 40, title: "Legend" },
  { minLevel: 41, maxLevel: 45, title: "Mythic" },
  { minLevel: 46, maxLevel: 50, title: "Epic" },
  { minLevel: 51, maxLevel: 60, title: "Immortal" },
  { minLevel: 61, maxLevel: 70, title: "Divine" },
  { minLevel: 71, maxLevel: 80, title: "Transcendent" },
  { minLevel: 81, maxLevel: 90, title: "Cosmic" },
  { minLevel: 91, maxLevel: 100, title: "Eternal" },
  { minLevel: 101, maxLevel: Infinity, title: "Unstoppable" },
];

export interface LevelInfo {
  level: number;
  currentLevelThreshold: number;
  nextLevelThreshold: number;
  progressToNext: number; // 0-100
  medal: string;
  tierTitle: string;
}

const MINUTE = 60 * 1000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/**
 * Exact level progression as specified in the original plan
 * Level 1 is instant (0), then progression starts from Level 2
 * Early Levels (1-11): Quick wins to build momentum
 * Mid Levels (12-26): Steady progression
 * High Levels (27+): Long-term milestones
 */
const LEVEL_THRESHOLDS: Record<number, number> = {
  // Level 1 is instant (everyone starts here)
  1: 0,                 // Instant
  
  // Early Levels (2-11): Quick wins
  2: 30 * MINUTE,       // 30 minutes
  3: 1 * HOUR,          // 1 hour
  4: 2 * HOUR,          // 2 hours
  5: 4 * HOUR,          // 4 hours
  6: 8 * HOUR,          // 8 hours
  7: 12 * HOUR,         // 12 hours
  8: 1 * DAY,           // 1 day
  9: 1.5 * DAY,         // 1.5 days
  10: 2 * DAY,          // 2 days
  11: 3 * DAY,          // 3 days
  
  // Mid Levels (12-26): Days to months
  12: 4 * DAY,          // 4 days
  13: 5 * DAY,          // 5 days
  14: 6 * DAY,          // 6 days
  15: 7 * DAY,          // 7 days (1 week)
  16: 10 * DAY,         // 10 days
  17: 14 * DAY,         // 2 weeks
  18: 17.5 * DAY,       // 2.5 weeks
  19: 21 * DAY,         // 3 weeks
  20: 24.5 * DAY,       // 3.5 weeks
  21: 28 * DAY,         // 4 weeks (1 month)
  22: 45 * DAY,         // 1.5 months
  23: 60 * DAY,         // 2 months
  24: 75 * DAY,         // 2.5 months
  25: 90 * DAY,         // 3 months
  26: 120 * DAY,        // 4 months
  
  // High Levels (27+): Long-term milestones
  27: 150 * DAY,        // 5 months
  28: 180 * DAY,        // 6 months
  29: 240 * DAY,        // 8 months
  30: 300 * DAY,        // 10 months
  31: 365 * DAY,        // 12 months (1 year)
  32: 548 * DAY,        // 1.5 years
  33: 730 * DAY,        // 2 years
  34: 1095 * DAY,       // 3 years
  35: 1825 * DAY,       // 5 years
  36: 3650 * DAY,       // 10 years
};

/**
 * Get the time threshold for a given level
 */
export function getLevelThreshold(level: number): number {
  // Return exact threshold if defined
  if (LEVEL_THRESHOLDS[level] !== undefined) {
    return LEVEL_THRESHOLDS[level];
  }
  
  // For levels beyond our defined thresholds, continue with exponential growth
  // (This handles edge cases but shouldn't normally be reached)
  const maxLevel = Math.max(...Object.keys(LEVEL_THRESHOLDS).map(Number));
  if (level > maxLevel) {
    const baseThreshold = LEVEL_THRESHOLDS[maxLevel];
    const yearsMultiplier = Math.pow(1.5, level - maxLevel);
    return Math.floor(baseThreshold * yearsMultiplier);
  }
  
  return 0;
}

/**
 * Get the medal emoji for a given level (cycles through LEVEL_MEDALS)
 */
export function getLevelMedal(level: number): string {
  const index = (level - 1) % LEVEL_MEDALS.length;
  return LEVEL_MEDALS[index];
}

/**
 * Get the tier title for a given level
 */
export function getLevelTierTitle(level: number): string {
  const tier = LEVEL_TIERS.find(
    t => level >= t.minLevel && level <= t.maxLevel
  );
  return tier?.title || "Unstoppable";
}

/**
 * Get the tier ordinal (Roman numeral) for a given level based on position within its tier
 * Examples: Level 1 = "I", Level 3 = "III", Level 6 = "I" (first in Apprentice tier)
 */
export function getTierOrdinal(level: number): string {
  const tier = LEVEL_TIERS.find(
    t => level >= t.minLevel && level <= t.maxLevel
  );
  
  if (!tier) return "I";
  
  // Calculate position within tier (1-based)
  const positionInTier = level - tier.minLevel + 1;
  
  // Convert to Roman numeral (I-V)
  const romanNumerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];
  return romanNumerals[positionInTier - 1] || "I";
}

/**
 * Calculate current level and progress from elapsed time
 */
export function calculateLevelInfo(elapsedMs: number): LevelInfo {
  let currentLevel = 1;
  
  // Find the highest level threshold that's been passed
  for (let level = 1; level <= 1000; level++) {
    const threshold = getLevelThreshold(level);
    if (elapsedMs >= threshold) {
      currentLevel = level;
    } else {
      break;
    }
  }
  
  const currentLevelThreshold = getLevelThreshold(currentLevel);
  const nextLevelThreshold = getLevelThreshold(currentLevel + 1);
  const progressInLevel = elapsedMs - currentLevelThreshold;
  const levelDuration = nextLevelThreshold - currentLevelThreshold;
  const progressToNext = Math.min((progressInLevel / levelDuration) * 100, 100);
  
  return {
    level: currentLevel,
    currentLevelThreshold,
    nextLevelThreshold,
    progressToNext,
    medal: getLevelMedal(currentLevel),
    tierTitle: getLevelTierTitle(currentLevel),
  };
}

/**
 * Get all unlocked levels up to the current level
 */
export function getUnlockedLevels(elapsedMs: number): number[] {
  const { level: currentLevel } = calculateLevelInfo(elapsedMs);
  return Array.from({ length: currentLevel }, (_, i) => i + 1);
}

// ========================================
// ACHIEVEMENT GROUP CONSTANTS
// ========================================

export interface LevelGroup {
  id: string;
  title: string;
  minLevel: number;
  maxLevel: number;
}

export const LEVEL_GROUPS: LevelGroup[] = [
  { id: "early", title: "Early Levels – Quick Wins", minLevel: 1, maxLevel: 11 },
  { id: "mid", title: "Mid Levels – Steady Progress", minLevel: 12, maxLevel: 26 },
  { id: "high", title: "High Levels – Long-term Goals", minLevel: 27, maxLevel: Infinity },
];

/**
 * Build visible levels list: all unlocked levels + next 3 upcoming levels
 * @param unlockedLevels - Array of unlocked level numbers
 * @returns Array of level numbers to display (unlocked + next 3)
 * 
 * Examples:
 * - If unlocked = [1,2,3,4,5], returns [1,2,3,4,5,6,7,8]
 * - If unlocked = [], returns [1,2,3] (first 3 levels)
 * - If unlocked = [1,2,3,...,35], returns [1,2,3,...,35] (all 35, no more levels defined)
 */
export function getVisibleLevels(unlockedLevels: number[]): number[] {
  if (unlockedLevels.length === 0) {
    return [1, 2, 3];
  }
  
  const maxUnlocked = Math.max(...unlockedLevels);
  const nextThreeLevels = [maxUnlocked + 1, maxUnlocked + 2, maxUnlocked + 3];
  
  const maxDefinedLevel = Math.max(...Object.keys(LEVEL_THRESHOLDS).map(Number));
  const validNextLevels = nextThreeLevels.filter(level => level <= maxDefinedLevel);
  
  return [...unlockedLevels, ...validNextLevels];
}

export type SeverityTier = "pathetic" | "weak" | "disappointing" | "tragic" | "devastating";

export interface SeverityLevel {
  tier: SeverityTier;
  threshold: number;
  title: string;
  confirmationType: "button" | "type-give-up" | "type-goal";
}

export const SEVERITY_TIERS: SeverityLevel[] = [
  { tier: "pathetic", threshold: 0, title: "Pathetic", confirmationType: "button" },
  { tier: "weak", threshold: 60 * 60 * 1000, title: "Weak", confirmationType: "button" },
  { tier: "disappointing", threshold: 24 * 60 * 60 * 1000, title: "Disappointing", confirmationType: "button" },
  { tier: "tragic", threshold: 7 * 24 * 60 * 60 * 1000, title: "Tragic", confirmationType: "type-give-up" },
  { tier: "devastating", threshold: 14 * 24 * 60 * 60 * 1000, title: "Devastating", confirmationType: "type-goal" },
];

export const SHAME_MESSAGES: Record<SeverityTier, string[]> = {
  pathetic: [
    "Couldn't hack one fucking hour? What a joke.",
    "Not even 60 minutes. You're a goddamn embarrassment.",
    "An hour too tough? Holy shit, grow a spine.",
    "Most try for hours. You? Instant fucking quitter.",
    "Gave up quicker than a shitty rom-com ends.",
    "Couldn't survive a lunch break without caving, you weak fuck.",
    "Less than an hour. Do you even want this, asshole?",
    "Quit before motivation could even ghost you. Pathetic.",
    "An hour's nothing. This is soul-crushingly lame.",
    "Bar on the floor, and you still face-planted, dipshit.",
    "Excuses not even formed yet. What a rushed failure.",
    "Sixty minutes maxed you out. Laughable shit.",
    "Didn't even pretend to try. Total loser move.",
    "Instant gratification? More like instant fucking surrender.",
    "Months for winners. Minutes for your sorry ass.",
  ],
  weak: [
    "Bailing before a full day? That's your worthless legacy now.",
    "Hours, not a day. You're a spineless fucking coward.",
    "Couldn't hit 24 hours. Screams \"total failure.\"",
    "Most would puke from shame resetting this fast, you hack.",
    "Quit before takeoff. What a gutless prick.",
    "Not one full day? You're a joke, seriously.",
    "A day too brutal? Pull your head out your ass.",
    "Outlasted Netflix but not self-improvement? Bullshit.",
    "Couldn't beat a workday. Pathetic office drone.",
    "Gave up mid-cheer. Thanks for nothing, traitor.",
    "Under 24 hours. That's not effort; that's surrender.",
    "Talk change, can't hack one Earth spin? Hypocrite fuck.",
    "Full day ambitious? You're delusional and weak.",
    "Faster reset than NYE bullshit resolutions. Predictable.",
    "One day snapped you. Fragile little bitch.",
  ],
  disappointing: [
    "Real momentum built. Days flushed like yesterday's shit.",
    "Days of grind, nuked for a weak-ass whim. Worth it, fucker?",
    "Built something solid. Now torching it to ash.",
    "Days of discipline? Cashed in for momentary pussy shit.",
    "Had a streak. Past tense, you disappointing sack.",
    "Folks saw your glow-up. Now they'll see the crash, idiot.",
    "Nailed the grind, then bailed. What a tease.",
    "Days fighting urges? Straight to the goddamn landfill.",
    "Proved shit to yourself. Then erased it, moron.",
    "Days of \"no\"—ruined by one spineless \"yes.\"",
    "Good pattern brewing. You smashed it, vandal.",
    "This far and still folding? Unforgivable weakness.",
    "Were better. Now same old mediocre fuck again.",
    "Days prove you can. Choosing to suck instead.",
    "Days wasted. Ponder that, you self-sabotaging prick.",
  ],
  tragic: [
    "SO FUCKING CLOSE. Weeks vaporized in your betrayal.",
    "Seven days slaved away. Gone, you ungrateful shit.",
    "Had gold worth guarding. You burned it to cinders.",
    "Weeks forging steel will? Shattered like glass, pussy.",
    "Folks beamed with pride. Now just pity your ass.",
    "Conquered weekends—brutal feat. Tossing it like trash.",
    "Becoming unbreakable. Nah, just a has-been quitter.",
    "WEEKS, not days. And you're the dumb fuck tapping out.",
    "Inspired us all. Now you're quitters' hall-of-fame trash.",
    "Every goddamn day? Fertilizer for your failure garden.",
    "Proved weeks-strong. Why the hell stop, coward?",
    "Not a slip—a ballsy choice to eat shit and fail.",
    "Future you despises this gut-punch decision, traitor.",
    "Bed proud for weeks? Wake up ashamed, forever.",
    "Weeks-forged base? Demolition derby, driver.",
  ],
  devastating: [
    "MONTH-PLUS EMPIRE. You're the wrecking-ball asshole.",
    "Weeks of wins? Regret avalanche incoming, fuckwit.",
    "Life overhaul for weeks. Undoing it all, you destroyer.",
    "Became a badass. Killing them dead, you murderer.",
    "Every battle-hard day? Erased, you ungrateful cunt.",
    "Tasted freedom. Chaining yourself back, masochist.",
    "Transformation real. \"Was\"—your suicide note.",
    "Believers crushed. You just gutted their faith, betrayer.",
    "Weeks of iron? Eclipsed by your jelly-spine moment.",
    "Capable as fuck. Now? Commitment-phobic loser.",
    "Resisted dawn to dusk. All futile now, waster.",
    "Peak streak ever. Rendering it worthless garbage.",
    "Success saga penned. Ending: \"Gave up, the end.\"",
    "Weeks screaming \"I CAN.\" Deaf to it, you blind idiot.",
    "Old you in awe. Becoming that loser again—tragic.",
  ],
};

export function getSeverityTier(elapsed: number): SeverityLevel {
  for (let i = SEVERITY_TIERS.length - 1; i >= 0; i--) {
    if (elapsed >= SEVERITY_TIERS[i].threshold) {
      return SEVERITY_TIERS[i];
    }
  }
  return SEVERITY_TIERS[0];
}

export function getRandomShameMessage(tier: SeverityTier): string {
  const messages = SHAME_MESSAGES[tier];
  return messages[Math.floor(Math.random() * messages.length)];
}
