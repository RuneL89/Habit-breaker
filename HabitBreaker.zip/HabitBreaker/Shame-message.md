## Tier 1: Pathetic
**Time Range:** Less than 1 hour  
**Confirmation Required:** Button click only  
**Lost Achievements Display:** No

### Messages (15 total)

1. Couldn't hack one fucking hour? What a joke.
2. Not even 60 minutes. You're a goddamn embarrassment.
3. An hour too tough? Holy shit, grow a spine.
4. Most try for hours. You? Instant fucking quitter.
5. Gave up quicker than a shitty rom-com ends.
6. Couldn't survive a lunch break without caving, you weak fuck.
7. Less than an hour. Do you even want this, asshole?
8. Quit before motivation could even ghost you. Pathetic.
9. An hour's nothing. This is soul-crushingly lame.
10. Bar on the floor, and you still face-planted, dipshit.
11. Excuses not even formed yet. What a rushed failure.
12. Sixty minutes maxed you out. Laughable shit.
13. Didn't even pretend to try. Total loser move.
14. Instant gratification? More like instant fucking surrender.
15. Months for winners. Minutes for your sorry ass.

---

## Tier 2: Weak
**Time Range:** 1 hour to 1 day  
**Confirmation Required:** Button click only  
**Lost Achievements Display:** No

### Messages (15 total)

1. Bailing before a full day? That's your worthless legacy now.
2. Hours, not a day. You're a spineless fucking coward.
3. Couldn't hit 24 hours. Screams "total failure."
4. Most would puke from shame resetting this fast, you hack.
5. Quit before takeoff. What a gutless prick.
6. Not one full day? You're a joke, seriously.
7. A day too brutal? Pull your head out your ass.
8. Outlasted Netflix but not self-improvement? Bullshit.
9. Couldn't beat a workday. Pathetic office drone.
10. Gave up mid-cheer. Thanks for nothing, traitor.
11. Under 24 hours. That's not effort; that's surrender.
12. Talk change, can't hack one Earth spin? Hypocrite fuck.
13. Full day ambitious? You're delusional and weak.
14. Faster reset than NYE bullshit resolutions. Predictable.
15. One day snapped you. Fragile little bitch.

---

## Tier 3: Disappointing
**Time Range:** 1 day to 1 week  
**Confirmation Required:** Button click only  
**Lost Achievements Display:** Yes (shows which badges will be lost)

### Messages (15 total)

1. Real momentum built. Days flushed like yesterday's shit.
2. Days of grind, nuked for a weak-ass whim. Worth it, fucker?
3. Built something solid. Now torching it to ash.
4. Days of discipline? Cashed in for momentary pussy shit.
5. Had a streak. Past tense, you disappointing sack.
6. Folks saw your glow-up. Now they'll see the crash, idiot.
7. Nailed the grind, then bailed. What a tease.
8. Days fighting urges? Straight to the goddamn landfill.
9. Proved shit to yourself. Then erased it, moron.
10. Days of "no"—ruined by one spineless "yes."
11. Good pattern brewing. You smashed it, vandal.
12. This far and still folding? Unforgivable weakness.
13. Were better. Now same old mediocre fuck again.
14. Days prove you can. Choosing to suck instead.
15. Days wasted. Ponder that, you self-sabotaging prick.

---

## Tier 4: Tragic
**Time Range:** 1 week to 2 weeks  
**Confirmation Required:** Must type "I GIVE UP" exactly  
**Lost Achievements Display:** Yes (shows which badges will be lost)

### Messages (15 total)

1. SO FUCKING CLOSE. Weeks vaporized in your betrayal.
2. Seven days slaved away. Gone, you ungrateful shit.
3. Had gold worth guarding. You burned it to cinders.
4. Weeks forging steel will? Shattered like glass, pussy.
5. Folks beamed with pride. Now just pity your ass.
6. Conquered weekends—brutal feat. Tossing it like trash.
7. Becoming unbreakable. Nah, just a has-been quitter.
8. WEEKS, not days. And you're the dumb fuck tapping out.
9. Inspired us all. Now you're quitters' hall-of-fame trash.
10. Every goddamn day? Fertilizer for your failure garden.
11. Proved weeks-strong. Why the hell stop, coward?
12. Not a slip—a ballsy choice to eat shit and fail.
13. Future you despises this gut-punch decision, traitor.
14. Bed proud for weeks? Wake up ashamed, forever.
15. Weeks-forged base? Demolition derby, driver.

---

## Tier 5: Devastating
**Time Range:** 2+ weeks  
**Confirmation Required:** Must type the user's entire goal statement exactly  
**Lost Achievements Display:** Yes (shows which badges will be lost)

### Messages (15 total)

1. MONTH-PLUS EMPIRE. You're the wrecking-ball asshole.
2. Weeks of wins? Regret avalanche incoming, fuckwit.
3. Life overhaul for weeks. Undoing it all, you destroyer.
4. Became a badass. Killing them dead, you murderer.
5. Every battle-hard day? Erased, you ungrateful cunt.
6. Tasted freedom. Chaining yourself back, masochist.
7. Transformation real. "Was"—your suicide note.
8. Believers crushed. You just gutted their faith, betrayer.
9. Weeks of iron? Eclipsed by your jelly-spine moment.
10. Capable as fuck. Now? Commitment-phobic loser.
11. Resisted dawn to dusk. All futile now, waster.
12. Peak streak ever. Rendering it worthless garbage.
13. Success saga penned. Ending: "Gave up, the end."
14. Weeks screaming "I CAN." Deaf to it, you blind idiot.
15. Old you in awe. Becoming that loser again—tragic.

---

## Technical Details

### Severity Tier Thresholds
- **Pathetic:** 0 - 59 minutes
- **Weak:** 1 hour - 23 hours 59 minutes
- **Disappointing:** 1 day - 6 days 23 hours 59 minutes
- **Tragic:** 1 week - 13 days 23 hours 59 minutes
- **Devastating:** 14+ days

### Message Selection
- One random message is selected from the appropriate tier each time the shame dialog opens
- The randomization ensures variety and prevents users from seeing the same message repeatedly
- Messages are personalized with the user's specific habit name and goal

### Confirmation Escalation
The app uses increasingly difficult confirmation requirements as streaks get longer:

1. **Tiers 1-3:** Simple button click ("I'm Giving Up")
2. **Tier 4:** Must type "I GIVE UP" exactly
3. **Tier 5:** Must retype their entire goal statement exactly

This escalation creates friction that increases with the value of what's being lost, encouraging users to reconsider before resetting long streaks.

---

**Total Messages:** 75 (15 per tier)  
**Last Updated:** October 26, 2025