import { cn } from "@/lib/utils";

interface AchievementBadgeProps {
  emoji: string;
  label: string;
  unlocked: boolean;
  progress?: number;
  duration?: string; // Duration requirement for this level (e.g., "3 days", "2 weeks")
}

export function AchievementBadge({ emoji, label, unlocked, progress, duration }: AchievementBadgeProps) {
  return (
    <div className="flex flex-col items-center gap-2" data-testid={`badge-${label.toLowerCase().replace(/\s+/g, '-')}`}>
      <div
        className={cn(
          "w-16 h-16 rounded-full flex items-center justify-center text-3xl transition-all duration-300",
          unlocked
            ? "bg-primary/10 shadow-lg scale-100"
            : "bg-muted/50 opacity-40 grayscale scale-95"
        )}
      >
        {emoji}
      </div>
      <div className="text-center">
        <div className={cn("text-xs font-medium", unlocked ? "text-foreground" : "text-muted-foreground")}>
          {label}
        </div>
        {unlocked && duration && (
          <div className="text-xs text-muted-foreground mt-0.5">{duration}</div>
        )}
        {!unlocked && progress !== undefined && progress > 0 && (
          <div className="text-xs text-muted-foreground">{Math.round(progress * 100)}%</div>
        )}
      </div>
    </div>
  );
}
