import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { TimerDisplay } from "./TimerDisplay";
import { AchievementBadge } from "./AchievementBadge";
import { ShameModal } from "./ShameModal";
import { type Habit, calculateLevelInfo, getLevelMedal, getLevelTierTitle, getLevelThreshold, getTierOrdinal, getVisibleLevels, LEVEL_GROUPS } from "@shared/schema";
import { formatDuration } from "@/lib/time";
import { RotateCcw, Trophy, Trash2 } from "lucide-react";
import { useState } from "react";

interface HabitCardProps {
  habit: Habit;
  onReset: (habitId: string) => void;
  onDelete: (habitId: string) => void;
}

export function HabitCard({ habit, onReset, onDelete }: HabitCardProps) {
  const [showAchievements, setShowAchievements] = useState(false);
  const [showShameModal, setShowShameModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const elapsed = Date.now() - habit.startedAt;
  
  // Calculate current level and progress
  const { level, progressToNext, medal, tierTitle, nextLevelThreshold, currentLevelThreshold } = calculateLevelInfo(elapsed);
  const timeToNextLevel = Math.max(0, nextLevelThreshold - elapsed); // Clamp to 0 if negative
  
  // Get unlocked levels (post-migration these are numbers)
  const unlockedLevels = habit.achievementsUnlocked as unknown as number[];
  const unlockedCount = unlockedLevels.length;
  
  // Get visible levels (unlocked + next 3)
  const visibleLevels = getVisibleLevels(unlockedLevels);
  
  // Group visible levels by category
  const groupedLevels = LEVEL_GROUPS.map(group => {
    const levelsInGroup = visibleLevels.filter(
      lvl => lvl >= group.minLevel && lvl <= group.maxLevel
    );
    
    if (levelsInGroup.length === 0) return null;
    
    const levelData = levelsInGroup.map(lvl => {
      const unlockThreshold = getLevelThreshold(lvl);
      const isUnlocked = unlockedLevels.includes(lvl);
      
      return {
        level: lvl,
        medal: getLevelMedal(lvl),
        tierTitle: getLevelTierTitle(lvl),
        tierOrdinal: getTierOrdinal(lvl),
        duration: formatDuration(unlockThreshold),
        unlocked: isUnlocked,
      };
    });
    
    return {
      group,
      levels: levelData,
    };
  }).filter(Boolean);

  return (
    <Card className="p-6 hover-elevate" data-testid={`card-habit-${habit.id}`}>
      <div className="flex flex-col gap-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0">
            <div className="text-4xl flex-shrink-0" data-testid="text-habit-emoji">
              {habit.emoji}
            </div>
            <div className="min-w-0">
              <h3 className="text-2xl font-semibold truncate" data-testid="text-habit-name">
                {habit.name}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                Streak started {new Date(habit.startedAt).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowAchievements(!showAchievements)}
              className="flex-shrink-0"
              data-testid="button-toggle-achievements"
            >
              <Trophy className="w-4 h-4" />
              {unlockedCount > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs">
                  {unlockedCount}
                </Badge>
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowDeleteDialog(true)}
              className="flex-shrink-0"
              data-testid="button-delete-habit"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Level Display */}
        <div className="flex items-center gap-4 p-4 bg-primary/5 rounded-lg" data-testid="level-display">
          <div className="text-5xl" data-testid="text-level-medal">
            {medal}
          </div>
          <div className="flex-1">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold" data-testid="text-level-number">
                Level {level}
              </span>
              <span className="text-sm text-muted-foreground" data-testid="text-level-tier">
                {tierTitle}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {Math.round(progressToNext)}% to Level {level + 1}
            </p>
          </div>
        </div>

        <TimerDisplay startedAt={habit.startedAt} />

        {/* Progress to Next Level */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Next Level: {getLevelMedal(level + 1)} Level {level + 1}</span>
            <span className="font-medium">{Math.round(progressToNext)}%</span>
          </div>
          <div className="flex items-center justify-center py-1">
            <span className="text-xs text-muted-foreground" data-testid="text-countdown-timer">
              {formatDuration(timeToNextLevel)} remaining
            </span>
          </div>
          <Progress value={progressToNext} className="h-3" data-testid="progress-next-level" />
        </div>

        {showAchievements && (
          <div className="pt-4 border-t">
            <h4 className="text-sm font-semibold mb-4">Achievement Progress ({unlockedCount} unlocked)</h4>
            <div className="space-y-6 max-h-96 overflow-y-auto">
              {groupedLevels.map((groupData) => (
                <div key={groupData!.group.id}>
                  <h5 className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                    {groupData!.group.title}
                  </h5>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-6 p-4 bg-muted/30 rounded-lg">
                    {groupData!.levels.map((data) => (
                      <AchievementBadge
                        key={data.level}
                        emoji={data.medal}
                        label={`${data.tierTitle} ${data.tierOrdinal}`}
                        unlocked={data.unlocked}
                        duration={data.duration}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <Button
          variant="outline"
          onClick={() => setShowShameModal(true)}
          className="w-full rounded-full"
          data-testid="button-reset-habit"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset Timer
        </Button>
      </div>

      <ShameModal
        open={showShameModal}
        onClose={() => setShowShameModal(false)}
        onConfirmReset={() => onReset(habit.id)}
        habitName={habit.name}
        goal={habit.goal}
        elapsed={elapsed}
        achievementsUnlocked={unlockedLevels}
      />

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent data-testid="dialog-delete-habit">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Habit?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{habit.name}"? This will permanently remove all your progress and achievements. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => onDelete(habit.id)}
              className="bg-destructive text-destructive-foreground hover-elevate"
              data-testid="button-confirm-delete"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
