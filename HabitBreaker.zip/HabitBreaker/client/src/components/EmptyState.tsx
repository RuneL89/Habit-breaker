import { Sparkles } from "lucide-react";

export function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center" data-testid="empty-state">
      <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-6">
        <Sparkles className="w-12 h-12 text-primary" />
      </div>
      <h2 className="text-3xl font-bold mb-3">Ready to break a habit?</h2>
      <p className="text-lg text-muted-foreground max-w-md mb-6">
        Start tracking your progress and celebrate your achievements along the way!
      </p>
    </div>
  );
}
