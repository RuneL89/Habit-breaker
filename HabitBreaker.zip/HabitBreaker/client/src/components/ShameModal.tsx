import { useState, useMemo } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertTriangle, Flame, Skull } from "lucide-react";
import { getSeverityTier, getRandomShameMessage, calculateLevelInfo, getLevelMedal } from "@shared/schema";

interface ShameModalProps {
  open: boolean;
  onClose: () => void;
  onConfirmReset: () => void;
  habitName: string;
  goal: string;
  elapsed: number;
  achievementsUnlocked: number[];
}

function formatDuration(ms: number) {
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  const hours = Math.floor((ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));

  if (days > 0) {
    return `${days} day${days > 1 ? 's' : ''} and ${hours} hour${hours !== 1 ? 's' : ''}`;
  } else if (hours > 0) {
    return `${hours} hour${hours > 1 ? 's' : ''} and ${minutes} minute${minutes !== 1 ? 's' : ''}`;
  } else {
    return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
  }
}

export function ShameModal({ open, onClose, onConfirmReset, habitName, goal, elapsed, achievementsUnlocked }: ShameModalProps) {
  const [typedText, setTypedText] = useState("");
  const duration = formatDuration(elapsed);
  
  const severityLevel = useMemo(() => getSeverityTier(elapsed), [elapsed]);
  const shameMessage = useMemo(() => getRandomShameMessage(severityLevel.tier), [severityLevel.tier, open]);

  const handleClose = () => {
    setTypedText("");
    onClose();
  };

  const getRequiredText = () => {
    if (severityLevel.confirmationType === "type-give-up") {
      return "I GIVE UP";
    } else if (severityLevel.confirmationType === "type-goal") {
      return goal;
    }
    return "";
  };

  const requiredText = getRequiredText();
  const isTypingRequired = severityLevel.confirmationType !== "button";
  const canConfirm = !isTypingRequired || typedText === requiredText;

  const handleConfirm = () => {
    if (canConfirm) {
      onConfirmReset();
      handleClose();
    }
  };

  const getSeverityIcon = () => {
    switch (severityLevel.tier) {
      case "devastating":
      case "tragic":
        return <Skull className="w-6 h-6 text-destructive" />;
      case "disappointing":
        return <Flame className="w-6 h-6 text-destructive" />;
      default:
        return <AlertTriangle className="w-6 h-6 text-destructive" />;
    }
  };

  const getSeverityColor = () => {
    switch (severityLevel.tier) {
      case "devastating":
        return "bg-destructive/30";
      case "tragic":
        return "bg-destructive/20";
      case "disappointing":
        return "bg-destructive/15";
      default:
        return "bg-destructive/10";
    }
  };

  const currentLevel = useMemo(() => calculateLevelInfo(elapsed).level, [elapsed]);
  
  const showLostLevels = 
    (severityLevel.tier === "disappointing" || 
     severityLevel.tier === "tragic" || 
     severityLevel.tier === "devastating") && 
    currentLevel > 1;

  const lostLevels = useMemo(() => {
    if (!showLostLevels) return [];
    return achievementsUnlocked.filter(level => level > 0);
  }, [showLostLevels, achievementsUnlocked]);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-[90vw] sm:max-w-lg max-h-[90vh] overflow-y-auto" data-testid="dialog-shame" aria-describedby="shame-description">
        <DialogHeader className="space-y-2">
          <div className="flex justify-center">
            <div className={`w-12 h-12 rounded-full ${getSeverityColor()} flex items-center justify-center`}>
              {getSeverityIcon()}
            </div>
          </div>
          <DialogTitle className="text-xl font-bold text-center">
            {severityLevel.title}
          </DialogTitle>
          <div id="shame-description" className="text-center space-y-2 text-sm text-muted-foreground">
            <div className="text-sm">
              You only made it <span className="font-bold text-foreground">{duration}</span> before giving up.
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <div className="text-xs text-muted-foreground mb-1">Your goal was:</div>
              <div className="text-sm font-semibold text-foreground">"{goal}"</div>
            </div>
            <div className="text-sm font-medium text-destructive">
              {shameMessage}
            </div>
            {showLostLevels && (
              <div className="pt-2">
                <div className="text-sm font-semibold mb-2 text-destructive">
                  You'll drop from Level {currentLevel} to Level 0
                </div>
                <div className="text-xs font-semibold mb-2">Levels you'll lose forever:</div>
                <div className="flex flex-wrap gap-1.5 justify-center max-h-32 overflow-y-auto p-1">
                  {lostLevels.map((level) => (
                    <div
                      key={level}
                      className="px-2 py-1 bg-destructive/10 rounded-md flex items-center gap-1.5"
                    >
                      <span className="text-lg">{getLevelMedal(level)}</span>
                      <span className="text-xs font-medium text-destructive line-through">
                        Lvl {level}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogHeader>
        {isTypingRequired && (
          <div className="space-y-2 px-6">
            <Label htmlFor="confirm-text" className="text-xs font-medium">
              Type "{requiredText}" to confirm:
            </Label>
            <Input
              id="confirm-text"
              value={typedText}
              onChange={(e) => setTypedText(e.target.value)}
              placeholder={requiredText}
              className="text-center text-sm"
              data-testid="input-confirmation"
              autoFocus
            />
          </div>
        )}
        <DialogFooter className="flex-col sm:flex-col gap-2">
          <Button
            onClick={handleConfirm}
            variant="destructive"
            className="w-full rounded-full"
            disabled={!canConfirm}
            data-testid="button-confirm-reset"
          >
            I'm Giving Up
          </Button>
          <Button
            onClick={handleClose}
            variant="outline"
            className="w-full rounded-full"
            data-testid="button-cancel-reset"
          >
            Keep Going
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
