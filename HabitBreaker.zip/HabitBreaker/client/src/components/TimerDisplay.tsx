import { useEffect, useState } from "react";

interface TimerDisplayProps {
  startedAt: number;
}

export function TimerDisplay({ startedAt }: TimerDisplayProps) {
  const [elapsed, setElapsed] = useState(Date.now() - startedAt);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed(Date.now() - startedAt);
    }, 1000);

    return () => clearInterval(interval);
  }, [startedAt]);

  const days = Math.floor(elapsed / (1000 * 60 * 60 * 24));
  const hours = Math.floor((elapsed % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((elapsed % (1000 * 60)) / 1000);

  return (
    <div className="flex items-baseline justify-center gap-3 flex-wrap" data-testid="timer-display">
      {days > 0 && (
        <div className="flex flex-col items-center">
          <span className="text-5xl font-bold tabular-nums" data-testid="text-days">
            {days}
          </span>
          <span className="text-sm font-medium opacity-60">days</span>
        </div>
      )}
      <div className="flex flex-col items-center">
        <span className="text-5xl font-bold tabular-nums" data-testid="text-hours">
          {hours}
        </span>
        <span className="text-sm font-medium opacity-60">hours</span>
      </div>
      <div className="flex flex-col items-center">
        <span className="text-5xl font-bold tabular-nums" data-testid="text-minutes">
          {minutes}
        </span>
        <span className="text-sm font-medium opacity-60">min</span>
      </div>
      {days === 0 && (
        <div className="flex flex-col items-center">
          <span className="text-5xl font-bold tabular-nums" data-testid="text-seconds">
            {seconds}
          </span>
          <span className="text-sm font-medium opacity-60">sec</span>
        </div>
      )}
    </div>
  );
}
