import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface AddHabitDialogProps {
  onAdd: (name: string, emoji: string, goal: string, startedAt?: number) => void;
}

const EMOJI_OPTIONS = [
  "🚬", "🍺", "🍕", "💅", "📱", "🎮", "🍫", "☕", 
  "🛋️", "😴", "🤳", "🎯", "✨", "🌟", "💪", "🔥"
];

export function AddHabitDialog({ onAdd }: AddHabitDialogProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [goal, setGoal] = useState("");
  const [selectedEmoji, setSelectedEmoji] = useState("🎯");
  const [useCustomStart, setUseCustomStart] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedHour, setSelectedHour] = useState("12");
  const [selectedMinute, setSelectedMinute] = useState("00");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && goal.trim()) {
      let startedAt: number | undefined = undefined;
      
      if (useCustomStart && selectedDate) {
        const customDate = new Date(selectedDate);
        customDate.setHours(parseInt(selectedHour) || 0);
        customDate.setMinutes(parseInt(selectedMinute) || 0);
        customDate.setSeconds(0);
        customDate.setMilliseconds(0);
        startedAt = customDate.getTime();
      }
      
      onAdd(name.trim(), selectedEmoji, goal.trim(), startedAt);
      setName("");
      setGoal("");
      setSelectedEmoji("🎯");
      setUseCustomStart(false);
      setSelectedDate(new Date());
      setSelectedHour("12");
      setSelectedMinute("00");
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="rounded-full px-8" data-testid="button-add-habit">
          <Plus className="w-4 h-4 mr-2" />
          Add Habit
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md" data-testid="dialog-add-habit">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Break a New Habit</DialogTitle>
            <DialogDescription>
              Choose what habit you want to break and track your progress!
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-6">
            <div className="space-y-2">
              <Label htmlFor="habit-name">Habit Name</Label>
              <Input
                id="habit-name"
                placeholder="e.g., Nail biting, Checking phone..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="rounded-lg"
                data-testid="input-habit-name"
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="habit-goal">Why are you breaking this habit?</Label>
              <Input
                id="habit-goal"
                placeholder="e.g., To look more professional, To be healthier..."
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="rounded-lg"
                data-testid="input-habit-goal"
              />
            </div>
            <div className="space-y-2">
              <Label>Choose an Icon</Label>
              <div className="grid grid-cols-8 gap-2">
                {EMOJI_OPTIONS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => setSelectedEmoji(emoji)}
                    className={`w-10 h-10 rounded-lg text-2xl flex items-center justify-center transition-all hover-elevate ${
                      selectedEmoji === emoji
                        ? "bg-primary/10 ring-2 ring-primary"
                        : "bg-muted/50"
                    }`}
                    data-testid={`button-emoji-${emoji}`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="space-y-4 pt-2 border-t">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="custom-start"
                  checked={useCustomStart}
                  onCheckedChange={(checked) => setUseCustomStart(checked as boolean)}
                  data-testid="checkbox-custom-start"
                />
                <Label
                  htmlFor="custom-start"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  Set when I last broke this habit
                </Label>
              </div>
              
              {useCustomStart && (
                <div className="space-y-4 pl-6">
                  <div className="space-y-2">
                    <Label htmlFor="custom-date">Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          id="custom-date"
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal rounded-lg",
                            !selectedDate && "text-muted-foreground"
                          )}
                          data-testid="button-select-date"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, "PPP") : <span>Pick a date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={setSelectedDate}
                          disabled={(date) => date > new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="custom-hour">Hour</Label>
                      <Input
                        id="custom-hour"
                        type="number"
                        min="0"
                        max="23"
                        value={selectedHour}
                        onChange={(e) => setSelectedHour(e.target.value)}
                        className="rounded-lg"
                        data-testid="input-hour"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="custom-minute">Minute</Label>
                      <Input
                        id="custom-minute"
                        type="number"
                        min="0"
                        max="59"
                        value={selectedMinute}
                        onChange={(e) => setSelectedMinute(e.target.value)}
                        className="rounded-lg"
                        data-testid="input-minute"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button
              type="submit"
              className="w-full rounded-full"
              disabled={!name.trim() || !goal.trim()}
              data-testid="button-submit-habit"
            >
              Start Tracking
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
