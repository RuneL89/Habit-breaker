import { TimerDisplay } from "../TimerDisplay";

export default function TimerDisplayExample() {
  const thirtyMinutesAgo = Date.now() - 30 * 60 * 1000;
  
  return <TimerDisplay startedAt={thirtyMinutesAgo} />;
}
