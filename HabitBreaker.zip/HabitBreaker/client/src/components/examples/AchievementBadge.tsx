import { AchievementBadge } from "../AchievementBadge";

export default function AchievementBadgeExample() {
  return (
    <div className="flex gap-6 p-6">
      <AchievementBadge emoji="⭐" label="1 Hour" unlocked={true} />
      <AchievementBadge emoji="🌟" label="6 Hours" unlocked={true} />
      <AchievementBadge emoji="🏆" label="1 Day" unlocked={false} progress={0.65} />
      <AchievementBadge emoji="💎" label="3 Days" unlocked={false} />
    </div>
  );
}
