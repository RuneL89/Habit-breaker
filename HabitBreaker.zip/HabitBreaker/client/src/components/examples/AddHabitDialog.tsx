import { AddHabitDialog } from "../AddHabitDialog";

export default function AddHabitDialogExample() {
  return (
    <div className="p-6">
      <AddHabitDialog 
        onAdd={(name, emoji, goal) => console.log("Add habit:", name, emoji, goal)} 
      />
    </div>
  );
}
