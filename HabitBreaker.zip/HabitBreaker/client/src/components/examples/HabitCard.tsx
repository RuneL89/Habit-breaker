import { HabitCard } from "../HabitCard";

export default function HabitCardExample() {
  const mockHabit = {
    id: "1",
    name: "Nail Biting",
    emoji: "💅",
    goal: "To look more professional at work",
    startedAt: Date.now() - (8 * 60 * 60 * 1000),
    achievementsUnlocked: ["1hour", "6hours"],
  };

  return (
    <div className="max-w-2xl p-6">
      <HabitCard 
        habit={mockHabit} 
        onReset={(id) => console.log("Reset habit:", id)} 
      />
    </div>
  );
}
