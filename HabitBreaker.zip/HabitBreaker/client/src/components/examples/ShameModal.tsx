import { useState } from "react";
import { ShameModal } from "../ShameModal";
import { Button } from "@/components/ui/button";

export default function ShameModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>Show Shame Modal</Button>
      <ShameModal
        open={open}
        onClose={() => setOpen(false)}
        onConfirmReset={() => {
          console.log("Habit reset");
          setOpen(false);
        }}
        habitName="nail biting"
        goal="To look more professional at work"
        elapsed={8 * 60 * 60 * 1000}
        achievementsUnlocked={["1hour", "6hours"]}
      />
    </div>
  );
}
