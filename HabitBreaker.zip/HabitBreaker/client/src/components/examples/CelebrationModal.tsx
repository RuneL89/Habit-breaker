import { useState } from "react";
import { CelebrationModal } from "../CelebrationModal";
import { Button } from "@/components/ui/button";

export default function CelebrationModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>Show Celebration</Button>
      <CelebrationModal
        open={open}
        onClose={() => setOpen(false)}
        achievement={{ emoji: "🏆", label: "1 Day" }}
        habitName="nail biting"
      />
    </div>
  );
}
