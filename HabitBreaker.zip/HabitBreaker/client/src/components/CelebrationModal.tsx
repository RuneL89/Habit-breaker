import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

interface CelebrationModalProps {
  open: boolean;
  onClose: () => void;
  achievement: {
    emoji: string;
    label: string;
  } | null;
  habitName: string;
}

const ENCOURAGEMENT_MESSAGES = [
  "You're crushing it!",
  "Amazing progress!",
  "Keep up the great work!",
  "You're unstoppable!",
  "Incredible achievement!",
  "You're on fire!",
];

export function CelebrationModal({ open, onClose, achievement, habitName }: CelebrationModalProps) {
  const [message] = useState(
    () => ENCOURAGEMENT_MESSAGES[Math.floor(Math.random() * ENCOURAGEMENT_MESSAGES.length)]
  );

  useEffect(() => {
    if (open) {
      const timer = setTimeout(() => {
        onClose();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [open, onClose]);

  if (!achievement) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md text-center" data-testid="dialog-celebration">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-primary/5 rounded-full blur-3xl animate-pulse" />
        </div>
        <DialogHeader className="space-y-4">
          <div className="flex justify-center">
            <div className="w-32 h-32 rounded-full bg-primary/10 flex items-center justify-center text-7xl animate-in zoom-in duration-500">
              {achievement.emoji}
            </div>
          </div>
          <DialogTitle className="text-3xl font-bold">
            {message}
          </DialogTitle>
          <DialogDescription className="text-lg">
            You've reached <span className="font-semibold text-foreground">{achievement.label}</span> without{" "}
            <span className="font-semibold text-foreground">{habitName}</span>!
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3 pt-4">
          <Button onClick={onClose} className="rounded-full" data-testid="button-close-celebration">
            <Sparkles className="w-4 h-4 mr-2" />
            Keep Going!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
