import { useState, useEffect } from "react";
import { HabitCard } from "@/components/HabitCard";
import { AddHabitDialog } from "@/components/AddHabitDialog";
import { CelebrationModal } from "@/components/CelebrationModal";
import { EmptyState } from "@/components/EmptyState";
import { type Habit, ACHIEVEMENT_MILESTONES, calculateLevelInfo, getLevelMedal, getLevelTierTitle } from "@shared/schema";
import { Sparkles } from "lucide-react";

/**
 * Migrate old milestone-based achievements to level-based system
 * Runs once on load if data is in old format
 */
function migrateLegacyAchievements(habits: Habit[]): Habit[] {
  return habits.map(habit => {
    // Check if achievements are in old string format (milestone IDs)
    if (habit.achievementsUnlocked.length > 0 && typeof habit.achievementsUnlocked[0] === 'string') {
      // Convert milestone IDs to level numbers
      const unlockedLevels = new Set<number>();
      
      habit.achievementsUnlocked.forEach(milestoneId => {
        const milestone = ACHIEVEMENT_MILESTONES.find(m => m.id === milestoneId);
        if (milestone) {
          // Find which level this milestone corresponds to
          const { level } = calculateLevelInfo(milestone.duration);
          // Add this level and all previous levels
          for (let i = 1; i <= level; i++) {
            unlockedLevels.add(i);
          }
        }
      });
      
      // Convert to numeric array and sort
      const levelsArray = Array.from(unlockedLevels).sort((a, b) => a - b);
      
      return {
        ...habit,
        achievementsUnlocked: levelsArray as any, // Store as numbers, DB schema still allows strings
      };
    }
    
    // Already in new format or empty
    return habit;
  });
}

export default function Home() {
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem("habits");
    if (saved) {
      const parsed = JSON.parse(saved);
      // Run migration and save if needed
      const migrated = migrateLegacyAchievements(parsed);
      const needsSave = JSON.stringify(parsed) !== JSON.stringify(migrated);
      if (needsSave) {
        localStorage.setItem("habits", JSON.stringify(migrated));
      }
      return migrated;
    }
    return [];
  });

  const [celebration, setCelebration] = useState<{
    open: boolean;
    achievement: { emoji: string; label: string } | null;
    habitName: string;
  }>({
    open: false,
    achievement: null,
    habitName: "",
  });

  useEffect(() => {
    localStorage.setItem("habits", JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    const interval = setInterval(() => {
      setHabits((currentHabits) => {
        let hasUpdates = false;
        const updatedHabits = currentHabits.map((habit) => {
          const elapsed = Date.now() - habit.startedAt;
          const { level: currentLevel } = calculateLevelInfo(elapsed);
          
          // achievementsUnlocked now stores level numbers (post-migration)
          const unlockedLevels = habit.achievementsUnlocked as unknown as number[];
          const highestUnlocked = unlockedLevels.length > 0 
            ? Math.max(...unlockedLevels) 
            : 0;

          // Synchronize achievements with current level
          // This ensures achievements array always matches actual progress
          const correctAchievements = Array.from({ length: currentLevel }, (_, i) => i + 1);
          
          // Check if achievements need updating (level up OR level down due to threshold changes)
          if (currentLevel !== highestUnlocked) {
            hasUpdates = true;
            
            // Only show celebration if we leveled UP (not down)
            if (currentLevel > highestUnlocked) {
              setCelebration({
                open: true,
                achievement: {
                  emoji: getLevelMedal(currentLevel),
                  label: `Level ${currentLevel}`,
                },
                habitName: habit.name,
              });
            }

            return {
              ...habit,
              achievementsUnlocked: correctAchievements as any,
            };
          }

          return habit;
        });

        return hasUpdates ? updatedHabits : currentHabits;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleAddHabit = (name: string, emoji: string, goal: string, startedAt?: number) => {
    const newHabit: Habit = {
      id: crypto.randomUUID(),
      name,
      emoji,
      goal,
      startedAt: startedAt ?? Date.now(),
      achievementsUnlocked: [],
    };
    setHabits([...habits, newHabit]);
  };

  const handleResetHabit = (habitId: string) => {
    setHabits(
      habits.map((habit) =>
        habit.id === habitId
          ? { ...habit, startedAt: Date.now(), achievementsUnlocked: [] }
          : habit
      )
    );
  };

  const handleDeleteHabit = (habitId: string) => {
    setHabits(habits.filter((habit) => habit.id !== habitId));
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <h1 className="text-2xl font-bold" data-testid="text-app-title">
              Habit Breaker
            </h1>
          </div>
          <AddHabitDialog onAdd={handleAddHabit} />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {habits.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {habits.map((habit) => (
              <HabitCard
                key={habit.id}
                habit={habit}
                onReset={handleResetHabit}
                onDelete={handleDeleteHabit}
              />
            ))}
          </div>
        )}
      </main>

      <CelebrationModal
        open={celebration.open}
        onClose={() =>
          setCelebration({ open: false, achievement: null, habitName: "" })
        }
        achievement={celebration.achievement}
        habitName={celebration.habitName}
      />
    </div>
  );
}
