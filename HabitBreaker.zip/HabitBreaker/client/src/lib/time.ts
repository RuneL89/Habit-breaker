/**
 * Format a duration in milliseconds to a compact human-readable string
 * Examples: "3d 4h", "2h 15m", "45m", "30s"
 */
export function formatDuration(ms: number): string {
  if (ms <= 0) return "0s";
  
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  const parts: string[] = [];
  
  if (days > 0) {
    parts.push(`${days}d`);
    const remainingHours = hours % 24;
    if (remainingHours > 0) {
      parts.push(`${remainingHours}h`);
    }
  } else if (hours > 0) {
    parts.push(`${hours}h`);
    const remainingMinutes = minutes % 60;
    if (remainingMinutes > 0) {
      parts.push(`${remainingMinutes}m`);
    }
  } else if (minutes > 0) {
    parts.push(`${minutes}m`);
  } else {
    parts.push(`${seconds}s`);
  }
  
  return parts.join(" ");
}

/**
 * Format a duration in milliseconds to a relative "time ago" string
 * Examples: "2h 15m ago", "3 days ago", "just now"
 */
export function formatTimeAgo(ms: number): string {
  if (ms <= 0) return "just now";
  
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    if (days === 1) return "1 day ago";
    return `${days} days ago`;
  } else if (hours > 0) {
    const remainingMinutes = minutes % 60;
    if (remainingMinutes > 0) {
      return `${hours}h ${remainingMinutes}m ago`;
    }
    return hours === 1 ? "1h ago" : `${hours}h ago`;
  } else if (minutes > 0) {
    return minutes === 1 ? "1m ago" : `${minutes}m ago`;
  } else if (seconds > 30) {
    return `${seconds}s ago`;
  } else {
    return "just now";
  }
}
