# Habit Breaker App - Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based (Gamification + Utility)

Drawing inspiration from:
- **Duolingo:** Playful gamification, achievement celebrations, encouraging feedback
- **Streaks:** Clean habit tracking, clear visual progress
- **Forest:** Positive reinforcement, gentle motivation

**Core Principle:** Make breaking bad habits feel like a game you're winning, not a test you're taking.

---

## Typography

**Font Family:** 
- Primary: 'Fredoka' (Google Fonts) - rounded, friendly, approachable
- Fallback: system-ui, sans-serif

**Hierarchy:**
- Page Title: text-4xl, font-bold (48px)
- Habit Names: text-2xl, font-semibold (24px)
- Timer Display: text-5xl, font-bold, tabular-nums (48px for main number)
- Achievement Titles: text-lg, font-semibold (18px)
- Body Text: text-base, font-medium (16px)
- Micro-copy/Labels: text-sm, font-normal (14px)

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8
- Tight spacing: p-2, gap-2 (form elements, badges)
- Standard spacing: p-4, gap-4 (cards, sections)
- Comfortable spacing: p-6, gap-6 (between components)
- Generous spacing: p-8, gap-8 (page sections)

**Container Structure:**
- Max width: max-w-4xl mx-auto
- Page padding: px-4 sm:px-6 lg:px-8
- Vertical rhythm: py-8 for main sections

---

## Component Library

### Navigation
**Top Bar:**
- Sticky header with app name/logo left-aligned
- "Add Habit" button right-aligned (rounded-full, px-6)
- Height: h-16 with shadow-sm

### Habit Cards
**Primary Display:**
- Rounded-2xl cards with shadow-lg
- Padding: p-6
- Grid layout: grid gap-6 (stacks on mobile, 2-col on md+)

**Card Contents:**
- Habit emoji/icon (text-4xl) top-left
- Habit name below icon
- Large timer display (days:hours:minutes format)
- Progress bar showing next milestone
- "Reset Timer" button (small, rounded-full)
- Achievement count badge (top-right corner)

### Timer Display
**Format:** Large tabular numbers with unit labels
```
[23] days [14] hours [32] minutes
```
- Numbers: text-5xl font-bold
- Units: text-sm font-medium, opacity-60

### Achievement System
**Milestone Badges:**
- Circular badges (w-16 h-16) with emoji icons
- Locked state: opacity-40, grayscale
- Unlocked state: shadow-lg, scale animation
- Badge grid: grid grid-cols-4 sm:grid-cols-6 gap-4

**Achievement Modal/Celebration:**
- Full-screen overlay with backdrop blur
- Confetti animation or sparkle effects
- Large badge display (w-32 h-32)
- Encouraging message
- "Keep Going!" dismiss button

### Forms
**Add/Edit Habit Modal:**
- Centered modal (max-w-md)
- Rounded-2xl with shadow-2xl
- Fields:
  - Habit name input (rounded-lg, p-4)
  - Emoji picker or icon selector
  - Custom milestone goals (optional advanced)
- Action buttons: full-width rounded-full

### Empty States
**No Habits Yet:**
- Centered illustration placeholder
- Friendly message: "Ready to break a habit?"
- Large CTA button to add first habit

---

## Interactive Elements

### Buttons
**Primary Actions:**
- Rounded-full, px-8 py-4
- Font-semibold, text-lg
- Shadow-md with hover:shadow-lg transition

**Secondary Actions:**
- Rounded-full, px-6 py-2
- Font-medium, text-base
- Border-2 style with transparent fill

**Icon Buttons:**
- Rounded-full, p-3
- Icons from Heroicons (outline for default, solid for active)

### Progress Indicators
**Linear Progress:**
- Rounded-full bars (h-3)
- Animated fill transition
- Show percentage to next milestone

### Animations
**Celebration Triggers:**
- Confetti burst when milestone reached
- Badge "pop" entrance (scale from 0.8 to 1)
- Gentle pulse on active timers (very subtle, 2-3s interval)

**Transitions:**
- All state changes: transition-all duration-300
- Modal entrance: fade + scale
- Card hover: subtle lift (hover:-translate-y-1)

---

## Interaction Patterns

**Timer Behavior:**
- Real-time countdown updates every minute
- Visual "pulse" indicator showing timer is active
- Warning state if approaching reset (accidental trigger protection)

**Achievement Unlock Flow:**
1. Timer reaches milestone
2. Confetti animation triggers
3. Modal slides up with badge reveal
4. Encouraging message displays
5. Badge added to collection permanently

**Habit Management:**
- Swipe or long-press for quick actions on mobile
- Hover reveals edit/delete options on desktop
- Confirmation dialog for destructive actions

---

## Responsive Behavior

**Mobile (< 768px):**
- Single column habit cards
- Full-width modals
- Compact timer display (stacked format)
- Bottom sheet for add/edit forms

**Tablet/Desktop (≥ 768px):**
- 2-column habit grid
- Centered modals with backdrop
- Side-by-side timer components
- Hover interactions enabled

---

## Personality Elements

**Encouraging Messages:**
- Randomized positive affirmations on milestones
- Playful copy throughout ("You're crushing it!", "22 days strong! 💪")
- No shame or negative language

**Visual Personality:**
- Rounded corners everywhere (rounded-2xl, rounded-full)
- Generous use of emoji and playful icons
- Soft shadows for depth, never harsh borders
- Micro-interactions that feel responsive and alive